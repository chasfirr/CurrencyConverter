package com.example.currencyconvertertechtix.viewModels

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.currencyconvertertechtix.ConvertedCurrency
import com.example.currencyconvertertechtix.Currency
import com.example.currencyconvertertechtix.repository.CurrencyRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CurrencyViewModel(private val repository: CurrencyRepository) :
    ViewModel() {

    private val convertedCurrenciesLive = MutableLiveData<List<ConvertedCurrency>>()
    private var convertedCurrencies = ArrayList<ConvertedCurrency>()

    private fun addConvertedCurrency(c: ConvertedCurrency) {
        convertedCurrencies.add(c)
        convertedCurrenciesLive.value = convertedCurrencies
    }

    fun getConvertedCurrencies(): LiveData<List<ConvertedCurrency>> {
        return convertedCurrenciesLive
    }

    fun convertCurrency(to: String, from: String, amt: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val response = repository.convertCurrency(to, from, amt)
            if (response.body() != null) {
                val body = response.body()!!
                withContext(Dispatchers.Main) {
                    addConvertedCurrency(ConvertedCurrency(body.query.to, body.result))
                }
                Log.d("CCCCCC", body.toString())
            }
        }
    }

    fun resetConvertedCurrencies() {
        convertedCurrencies = ArrayList()
        convertedCurrenciesLive.value = convertedCurrencies
    }


    fun getCurrencies(): LiveData<List<Currency>> {
        return repository.getCurrencyFromDB()
    }

    fun addCurrencies(c: Currency) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addCurrencies(c)
        }
    }

}
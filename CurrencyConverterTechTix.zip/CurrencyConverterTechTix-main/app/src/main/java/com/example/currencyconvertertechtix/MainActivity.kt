package com.example.currencyconvertertechtix

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import com.example.currencyconvertertechtix.adapters.RecyclerAdapter
import com.example.currencyconvertertechtix.apis.CurrencyApi
import com.example.currencyconvertertechtix.apis.RetrofitHelper
import com.example.currencyconvertertechtix.database.CurrencyDatabase
import com.example.currencyconvertertechtix.databinding.ActivityMainBinding
import com.example.currencyconvertertechtix.repository.CurrencyRepository
import com.example.currencyconvertertechtix.utilities.CurrencyWorker
import com.example.currencyconvertertechtix.viewModels.CurrencyViewModel
import com.example.currencyconvertertechtix.viewModels.CurrencyViewModelFactory
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: CurrencyViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        val dao = CurrencyDatabase.getDB(this).currencyDAO()
        val api = RetrofitHelper.getInstance().create(CurrencyApi::class.java)
        val repository = CurrencyRepository(api, dao)
        viewModel = ViewModelProvider(
            this,
            CurrencyViewModelFactory(repository)
        )[CurrencyViewModel::class.java]

        viewModel.getCurrencies().observe(this) {
            if (it.isNotEmpty()) {
                val symbols = it.map { c -> c.Symbol }
                setUpSpinner(symbols)
            }
        }


        viewModel.getConvertedCurrencies().observe(this) {
            if (it.isNotEmpty()) {
                binding.recyclerView.adapter = RecyclerAdapter(it)
            }
        }

        setUpWorker()

    }

    private fun setUpSpinner(symbols: List<String>) {
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, symbols)
        binding.spinner.setAdapter(adapter)
        binding.spinner.setOnItemClickListener { view: AdapterView<*>, v: View, position: Int, l: Long ->
            convertSelectedCurrency(symbols[position], symbols)
        }
    }

    private fun convertSelectedCurrency(from: String, symbols: List<String>) {
        val amt = binding.edittext.text.toString().trim()
        if (amt != "") {
            if (symbols.isNotEmpty()) {
                val to = symbols[0]
                viewModel.convertCurrency(to, from, amt)
            }
            Log.d("CCCCCC", symbols.toString())
        }
    }

    private fun setUpWorker() {
        val constraint =
            Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val workerRequest = PeriodicWorkRequest
            .Builder(CurrencyWorker::class.java, 30L, TimeUnit.MINUTES)
            .setConstraints(constraint)
            .build()
        WorkManager.getInstance(applicationContext).enqueue(workerRequest)
    }
}